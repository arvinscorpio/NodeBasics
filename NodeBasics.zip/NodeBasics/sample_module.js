/*
exports.firstName = "arvin"; //export other modules

exports.randomNum = function(){
    return Math.random();
}*/

module.exports = function(){

    return Math.random();
    
}