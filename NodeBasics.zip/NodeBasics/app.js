console.log("Core Modules");

var os = require('os'); // os module

//console.log(os.platform());

var http = require('http'); //web server
console.log(http);