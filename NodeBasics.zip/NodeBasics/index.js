//npm init - to intialize package.json that is node application

//managing node pacakages
//npm install express --save -- install express and update package.json and create package-lock.json
//npm prune command cehck the dependencies in package.json and unbuilds the modules whcih is no more used


console.log("NPM Community Modules");

//install the module, --save: saves the dependency for this prohject in package.json
//npm i underscore --save 

console.log("My Demo App");

var app = require('express');

var _ = require('underscore');//node looks first in core and then in node_modules. note there is no relative path too for custom modules

var names = ["arvin", "balaraman", "AB", "BA"];

_.each(names, function(name){
    //console.log("The Name is : " + name);
});

// var nodetech = require('./tech.js'); // loading and caching the module
// console.log(nodetech().getInfo());

// // var nodetech0 = require('./tech');
// // nodetech0().setName("new node tech 0");
// // console.log(nodetech0().getInfo());

// var nodetech1 = require('./tech')();
// nodetech1.setName("new node tech 1");
// console.log(nodetech1.getInfo());

var nodetech = require('./tech');
var tech1 = nodetech('tech 1', 'this is demo on tech 1' );
var tech2 = nodetech('tech 2', 'this is demo on tech 2' );
var tech3 = nodetech('tech 3', 'this is demo on tech 3' );

console.log(tech1.getInfo());
console.log(tech2.getInfo());

//create a node application
//npm init - this creates package.jsobn with wizard