// mvoed inside exports to update in caching
// var name = "node"; //local variables
// var description = "this is the node demo";

module.exports = function (name, description) {
    
    var name = name; //local variables
    var description = description;

    var functions = {
        setName: function (nameIn) {
            this.name = nameIn;
        },
        setDescription: function (descriptionIn) {
            this.description = descriptionIn;
        },
        getInfo: function () {
            return {
                name: name,
                description: description
            }
        }
    };
    return functions;
}

