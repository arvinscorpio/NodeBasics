console.log("Handling web Server Events");
var http = require('http');

var server = http.createServer();

//a http(browser) request
//use http://localhost:3456/ in browse
server.on('request', function (req, res) {
    console.log("Request Received", req.headers);
    res.end("Thanks, I got your request");
});

//update from http to socket
//listen to high performance TCP events using sockets(update from http to web socket)
// use enable simple websocket client in chrome - ws://localhost:3456/
//consider third party socket libraires liek socket.io etc instead core http module
server.on('upgrade',function(req,sock,head){
    console.log("Upgrade th connection to a web socket connection");
});

//start server
var port = 3456;
server.listen(port, function () {
    console.log("Http server listening on port " + port);
});

