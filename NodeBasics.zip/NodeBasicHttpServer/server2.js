var connect = require('connect');

var app = connect()
    .use(function (req, res) {
        if (req.url == "/hello") {
            console.log("sending plain response");
            res.end("Hello from App");
        }
        else if (req.url == "/hello.json") {

            console.log("sending json response");

            var data = "Hello";
            var jsonData = JSON.stringify(data);
            //var data1 = {name: data, desc: "desci"}
            //var jsonData = JSON.stringify(data1);

            res.setHeader('Content-Type', 'application/json');
            res.end(jsonData);
        }
        else if (req.url == "/printRequestHeaders") {

            var headers = req.headers;
            console.log("echoing headers");
            console.log(headers);            
            res.end("Headers printed in console");
        }
        else if (req.url == "/statusCodeDemo") {

            console.log("sending 404 status code");

            res.statusCode = 404;
            res.end("Oops!, could not find something");
        }
        else{
            res.end("Nothing else matched");
        }

    })
    .listen(3456);


console.log("HTTP server is listening on port 3456");