var request = require('request');

request('http://localhost:3456/hello.json', function (error, response, body) {
//request('http://www.google.com', function (error, response, body) {
    if (!error && response.statusCode == 200) {
        console.log(body);
    }
    if (error) {
        console.log(error);
    }
});