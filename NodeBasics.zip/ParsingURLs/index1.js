console.log("Parsing URLs");

var url = require('url');

//url format: http protocol authentication - username:password, hostname:port, urlpath thereafter
var testurl = "http://arvin:7654123@localhost:3456/path/to/resource?reosurceId=someValue&resourceType=someType";

//instread of regex,we can use url module

var parsedUrlObject = url.parse(testurl, true);//true parameter converts the querystring to object instead of default string

console.log(parsedUrlObject);

var urlString = url.format(parsedUrlObject);//build your own url

console.log(urlString);

  //output
/*Url {
  protocol: 'http:',
  slashes: true,
  auth: 'arvin:7654123',
  host: 'localhost:3456',
  port: '3456',
  hostname: 'localhost',
  hash: null,
  search: '?reosurceId=someValue&resourceType=someType',
  query:
   [Object: null prototype] { reosurceId: 'someValue', resourceType: 'someType' },
  pathname: '/path/to/resource',
  path:
   '/path/to/resource?reosurceId=someValue&resourceType=someType',
  href:
   'http://arvin:7654123@localhost:3456/path/to/resource?reosurceId=someValue&resourceType=someType' }
http://arvin:7654123@localhost:3456/path/to/resource?reosurceId=someValue&resourceType=someType
   */