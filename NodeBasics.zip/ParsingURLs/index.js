console.log("working with query strings");

var queryString = require('querystring');

var testBaseUrl = "http://localhost:3456/path/to/resource";

var queryDataObject = {
    'resourceID':'1',
    'username':'arvin'
}

var stringFromObject = queryString.stringify(queryDataObject,";",":");
//var stringFromObject = queryString.stringify(queryDataObject);//defaults

console.log(testBaseUrl + "?"+stringFromObject);