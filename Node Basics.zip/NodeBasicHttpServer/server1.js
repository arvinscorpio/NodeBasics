//console.log("Basic HTTP Server");

var http = require('http');
var connect = require('connect');
var bodyParser = require('body-parser');

// //handler method to handle all the requests to this server
// var handlerMethod = function(req,res){
//     res.end("A response from the web server");
// }

// http.createServer(handlerMethod).listen(3456,'localhost');

// console.log("HTTP server is listening on port 3456");

var app = connect()
          .use(bodyParser.urlencoded(
            {extended:true}
            ))
        .use(function(req,res){
                var parsedInfo = {};

                parsedInfo.firstName = req.body.userFirstName;
                parsedInfo.lastName = req.body.userLastName;

                res.end("User infro parsed from form: "+ parsedInfo.firstName + " " + parsedInfo.lastName)

            }); 
            
http.createServer(app).listen(3456,'localhost');

console.log("HTTP server is listening on port 3456");