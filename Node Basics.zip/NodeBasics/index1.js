

//require and exports

console.log("testing the verisons");
console.log("updated verion is: " + process.version);

var myModule = require('./sample_module'); //import custom modules

console.log(myModule);
//console.log(myModule.randomNum());
console.log(myModule());

